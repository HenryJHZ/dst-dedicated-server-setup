return{
["workshop-358749986"] = { enabled = true }, --ExtendedIndicators
["workshop-362175979"] = { enabled = true }, --wormhole_marks
["workshop-374550642"] = { enabled = true,
    configuration_options =
    {
        MAXSTACKSIZE = 99
    }
}, --Increased Stack size
["workshop-375850593"] = { enabled = true }, --Extra Equip Slots
["workshop-378160973"] = { enabled = true }, --GlobalPositions
["workshop-666155465"] = { enabled = true }, --showme
["workshop-785295023"] = { enabled = true }, --Super Wall DST
["workshop-788825160"] = { enabled = true }, --Change Characters
["workshop-1204112832"] = { enabled = true }, --Worker Turkey
["workshop-1207269058"] = { enabled = true }, --Simple Health Bar DST
["workshop-1242907291"] = { enabled = true,
    configuration_options =
    {
        ICEBOX= "-1"
    }
}, --Icebox Perish Settings
["workshop-1802013732"] = { enabled = true }, --The Lazy Hoarder
["workshop-1951468597"] = { enabled = true }, --Sweet House
["workshop-2078243581"] = { enabled = true }, --Display Attack Range
["workshop-2229630615"] = { enabled = true }, --New Boat Shapes
["workshop-2289662010"] = { enabled = true } --Rail Cart
}